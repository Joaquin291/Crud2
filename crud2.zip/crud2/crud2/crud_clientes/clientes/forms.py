from django import forms 
from .models import Mensajes

class MensajesForm(forms.ModelForm):
    class Meta:
        model=Mensajes
        fields='__all__'